# script de entrenamiento y evaluación (placeholder)
