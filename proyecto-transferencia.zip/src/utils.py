# utilidades comunes (placeholder)
