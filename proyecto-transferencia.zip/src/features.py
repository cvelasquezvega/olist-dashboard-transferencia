# funciones de ingeniería de características (placeholder)
